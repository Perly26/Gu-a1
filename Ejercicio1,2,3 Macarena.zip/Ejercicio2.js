//Clase de producto y precio en un constructor 
class Producto {
    constructor(nombre, precio) {
        this.nombre = nombre;
        this.precio = precio;
    }

    //Mostrar detalles del producto más precio
    mostrarDetalles() {
        console.log(`Producto: ${this.nombre}, Precio: $${this.precio}`);
    }
}

//Crear productos y mostrar detalles en pantalla
new Producto("Laptop", 246000).mostrarDetalles();
new Producto("Teléfono", 88000).mostrarDetalles();
new Producto("Audífonos", 44000).mostrarDetalles();
