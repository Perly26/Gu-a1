//Clase de trabajador con nombre y sueldo
class Trabajador {
    constructor(nombre, sueldo) {
        this.nombre = nombre;
        this.sueldo = sueldo;
    }
    //Imprimir en pantalla nombre y sueldo
    mostrarDetalles() {
        console.log(`Nombre: ${this.nombre}, Sueldo: $${this.sueldo}`);
    }
}

//Clase heredada de trabajador para el gerente, usando conector extends
class Gerente extends Trabajador {
    constructor(nombre, sueldo, departamento) {
        //Esto se hereda de la clase anterior, clase trabajador
        super(nombre, sueldo);  
        //Se añade el departamento
        this.departamento = departamento;
    }

    
    mostrarDetalles() {
        console.log(`Nombre: ${this.nombre}, Sueldo: $${this.sueldo}, Departamento: ${this.departamento}`);
    }
}

//Mostrar en pantalla detalles del trabajador y el gerente como nuevo
new Trabajador("Juan", 1500).mostrarDetalles();
new Trabajador("Ana", 1800).mostrarDetalles();
new Gerente("Carlos", 3000, "Ventas").mostrarDetalles();
new Gerente("Laura", 3500, "Marketing").mostrarDetalles();
