//Función para obtener el valor de entrada del usuario
function obtenerValor(mensaje) {
    return parseFloat(prompt(mensaje));
}

//Función para calcular el área de un círculo
function areaCirculo() {
    let radio = obtenerValor("Ingrese el valor del radio del círculo:");
    let area = Math.PI * Math.pow(radio, 2);
    alert("El área del círculo es: " + area.toFixed(2));
}

//función para calcular el área de un triángulo
function areaTriangulo() {
    let base = obtenerValor("Ingrese el valor de la base del triángulo:");
    let altura = obtenerValor("Ingrese el valor de la altura del triángulo:");
    let area = (base * altura) / 2;
    alert("El área del triángulo es: " + area.toFixed(2));
}

//Función para calcular el área de un rectangulo
function areaRectangulo() {
    let base = obtenerValor("Ingrese el valor de la base del rectángulo:");
    let altura = obtenerValor("Ingrese el valor de la altura del rectángulo:");
    let area = base * altura;
    alert("El área del rectángulo es: " + area.toFixed(2));
}

//Funciones
areaCirculo();
areaTriangulo();
areaRectangulo();
